import numpy as np
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt

from skimage import io as sckio
from skimage.transform import rotate
from skimage import color
from skimage.filters import threshold_otsu
from skimage.segmentation import clear_border
from skimage.measure import label
from skimage.morphology import closing, square
from skimage.measure import regionprops
from skimage.color import label2rgb


count=0

base_image = "IMG_1633.JPG"
image = sckio.imread(base_image)
#plt.imshow(image)
#plt.show()

grayimg = color.rgb2gray(image)
#plt.imshow(grayimg,cmap="gray")

thresh = threshold_otsu(grayimg)
binary = grayimg > thresh
cp = closing(grayimg > thresh, square(3))
#plt.imshow(cp,cmap="gray")

# remove connected components of image
cleared_image = cp.copy()
clear_border(cleared_image)
#plt.imshow(clear_border,cmap="gray")

# label image 
label_image = label(cleared_image)
image_label = label2rgb(label_image, image=grayimg)

fig, ax = plt.subplots(ncols=1, nrows=1, figsize=(6, 6))
ax.imshow(image_label)


for region in regionprops(label_image):
    if region.area < 500:
        continue
    minr, minc, maxr, maxc = region.bbox
    rect = mpatches.Rectangle((minc, minr), maxc - minc, maxr - minr,fill=False, edgecolor='white', linewidth=2)
    
    crop_img = image_label[minr:maxr, minc:maxc]
    #plt.imshow(crop_img)
    plt.imsave("crop_img"+str(count)+".jpg", crop_img)
    
    count=count+1
    rotated_img = rotate(crop_img,angle=90)
    #plt.imshow(rotated_img)
    plt.imsave("rotated"+str(count)+".jpg",rotated_img)
print(count-1)